package com.atmecs.devpractice;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import android.util.Patterns;
import android.widget.Toast;
import android.widget.TextView;
import android.graphics.Color;
import androidx.appcompat.widget.Toolbar;
import android.content.Intent;


public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText editFirstName,editLastName,editPhoneNumber,editEmail,editPwd,editConfirmPwd;
    private Button buttonSubmit;
    private AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        TextView login = (TextView)findViewById(R.id.lnkLogin);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        editFirstName = (EditText) findViewById(R.id.input_firstname);
        editLastName = (EditText) findViewById(R.id.input_lastname);
        editPhoneNumber = (EditText) findViewById(R.id.input_phnumber);
        editEmail = (EditText) findViewById(R.id.input_email);
        editPwd = (EditText) findViewById(R.id.input_pwd);
        editConfirmPwd = (EditText) findViewById(R.id.input_cnpwd);

        buttonSubmit = (Button) findViewById(R.id.buttonSignUp);

        awesomeValidation.addValidation(this,R.id.input_firstname, "^([A-Za-z ]+)", R.string.firstname_error);
        awesomeValidation.addValidation(this, R.id.input_lastname, "^([A-Za-z ]+)", R.string.lastname_error);
        awesomeValidation.addValidation(this, R.id.input_phnumber, "^[0-9]{10}", R.string.phn_number_error);
        awesomeValidation.addValidation(this, R.id.input_email, Patterns.EMAIL_ADDRESS, R.string.email_error);
        awesomeValidation.addValidation(this, R.id.input_pwd, "^((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})", R.string.pwd_error);
        awesomeValidation.addValidation(this, R.id.input_cnpwd, "^((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})", R.string.CnfmPwd_field_error);
        buttonSubmit.setOnClickListener(this);

        Toolbar toolbar= (Toolbar)findViewById(R.id.toolbar);

        toolbar.setTitle(R.string.registration_title);
        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();

            }
        });

    }

    private void submitForm() {
        if (awesomeValidation.validate()) {
            String passwordString=editPwd.getText().toString();
            String confirmPasswordString=editConfirmPwd.getText().toString();
            System.out.println("CHECK::"+passwordString+"::"+confirmPasswordString);
            if(!passwordString.equals(confirmPasswordString)){
                Toast.makeText(RegisterActivity.this,R.string.CnfmPwd_error,Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Registration Successfull", Toast.LENGTH_LONG).show();
            finish();
        }
    }
    @Override
    public void onClick(View view) {
        if (view == buttonSubmit) {
            submitForm();
        }
    }
}
