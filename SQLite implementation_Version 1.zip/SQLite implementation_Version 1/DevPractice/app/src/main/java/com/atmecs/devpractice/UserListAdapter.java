package com.atmecs.devpractice;

import android.app.Activity;
import android.content.Context;
import android.icu.text.Transliterator;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class UserListAdapter extends BaseAdapter {
    public Activity activity;
    List<UserList> listData;
   LayoutInflater layoutInflater;
    ImageView userImageUrl;

    public UserListAdapter(Activity activity,List<UserList> userLists){
        this.activity = activity;
        this.listData = userLists;
    }

    @Override
    public int getCount() {

        return listData.size();
    }
    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getViewTypeCount() {

        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }

    public View getView(int position, View view, ViewGroup vg) {
        ViewHolder holder;
        if(layoutInflater == null){
            layoutInflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (view == null) {

            view = layoutInflater.inflate(R.layout.fragment_users_profile_info, null);
            holder = new ViewHolder();
            holder.userId = (TextView) view.findViewById(R.id.user_profile_id);
            holder.userEmail = (TextView) view.findViewById(R.id.user_email);
            holder.userFirstName = (TextView) view.findViewById(R.id.user_first_name);
            holder.userLastName = (TextView) view.findViewById(R.id.user_last_name);
            userImageUrl = (ImageView) view.findViewById(R.id.profile_photo);

            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        holder.userId.setText(listData.get(position).getId());
        holder.userEmail.setText(listData.get(position).getEmail());
        holder.userFirstName.setText(listData.get(position).getFirstName());
        holder.userLastName.setText(listData.get(position).getLastName());
        Picasso.get().load(listData.get(position).getImgUrl()).into(userImageUrl);

        return view;
    }

    static class ViewHolder {
        TextView userId;
        TextView userEmail;
        TextView userFirstName;
        TextView userLastName;
    }
}
