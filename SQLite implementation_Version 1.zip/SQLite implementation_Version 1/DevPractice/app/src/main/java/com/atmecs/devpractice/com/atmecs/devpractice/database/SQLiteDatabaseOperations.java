package com.atmecs.devpractice.com.atmecs.devpractice.database;

import android.view.View;
import android.widget.TextView;

public class SQLiteDatabaseOperations {
    TextView textView;
    SQLiteDatabaseHandler sqLiteDatabaseHandler;

//    public void loadStudents(View view) {
//        sqLiteDatabaseHandler = new SQLiteDatabaseHandler(this, null, null, 1);
//        textView.setText(sqLiteDatabaseHandler.loadHandler());
//        studentid.setText("");
//        studentname.setText("");
//    }
}