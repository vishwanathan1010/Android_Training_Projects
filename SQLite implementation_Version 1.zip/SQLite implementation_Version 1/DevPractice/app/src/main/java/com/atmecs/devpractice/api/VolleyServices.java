package com.atmecs.devpractice.api;

import android.app.Activity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import cz.msebera.android.httpclient.Header;

public class VolleyServices {

    static APIResponseInterface apiResponseInterface;

    static StringRequest stringRequest;

    public VolleyServices(APIResponseInterface responseInterface) {
        this.apiResponseInterface = responseInterface;
    }

    public static void makeGetAPICall(String url, Activity activity) {

        stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {

                apiResponseInterface.onResponseInterface(response);
                System.out.println ("Success responseBodyString:" + response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        System.out.println("Failure responseBodyString:" + error);
                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(activity);
        requestQueue.add(stringRequest);
    }
}