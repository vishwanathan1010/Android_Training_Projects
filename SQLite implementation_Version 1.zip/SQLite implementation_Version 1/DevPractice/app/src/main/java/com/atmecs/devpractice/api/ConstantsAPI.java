package com.atmecs.devpractice.api;

public class ConstantsAPI {

    public final static String BASE_POST_URL = "https://reqres.in/api";
    public final static String LOGIN_URL = BASE_POST_URL + "/login";

    public final static String BASE_GET_URL = "https://reqres.in/api";
    public final static String GET_URL = BASE_GET_URL + "/users/2";

    public final static String BASE_PUT_URL = "https://reqres.in/api";
    public final static String PUT_URL = BASE_PUT_URL + "/users/2";

    public final static String LIST_USERS_URL = "https://reqres.in/api/users?page=2";

}
