package com.atmecs.devpractice;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    View rootView;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_lists, container, false);


        ArrayList userList = getListData();
        final ListView listView = (ListView) rootView.findViewById(R.id.user_list);
        listView.setAdapter(new CustomListAdapter(getContext(), userList));
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> a, View view, int position, long id) {
                ListProvider user = (ListProvider) listView.getItemAtPosition(position);
                Toast.makeText(getActivity(), "Selected :" + " " + user.getName() + ", " + user.getLocation(), Toast.LENGTH_SHORT).show();
            }
        });
   
        return rootView;

    }
    private ArrayList getListData() {
        ArrayList<ListProvider> list = new ArrayList<>();

        ListProvider firstItem = new ListProvider();
        firstItem.setName("Vaisista Sri Lakshmi");
        firstItem.setLocation("Manikonda");
        list.add(firstItem);

        ListProvider second_item = new ListProvider();
        second_item.setName("New Pakwaan Grand");
        second_item.setLocation("Gowchibowli");
        list.add(second_item);

        ListProvider third_item = new ListProvider();
        third_item.setName("Mahfia(Pure-Veg)");
        third_item.setLocation("Kondapur");
        list.add(third_item);

        return list;
    }
}
