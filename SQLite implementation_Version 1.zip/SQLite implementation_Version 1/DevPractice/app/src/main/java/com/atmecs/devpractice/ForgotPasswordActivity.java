package com.atmecs.devpractice;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.basgeekball.awesomevalidation.AwesomeValidation;


public class ForgotPasswordActivity extends AppCompatActivity {
    private EditText editForgotPasswordEmail;
    private Button sendButton;
    private AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        editForgotPasswordEmail = (EditText) findViewById(R.id.input_forgot_password);

        sendButton = (Button) findViewById(R.id.button_send_link);

        awesomeValidation.addValidation(this, R.id.input_forgot_password, Patterns.EMAIL_ADDRESS, R.string.forgotpassword_email_error);

        Toolbar toolbar= (Toolbar)findViewById(R.id.toolbar);

        toolbar.setTitle(R.string.forgot_password_title);
        toolbar.setTitleTextColor(Color.WHITE);
        toolbar.setNavigationIcon(R.drawable.ic_arrow_back_black_24dp);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void onSendButtonClick(View view) {
        if (awesomeValidation.validate()) {
            finish();
            Toast.makeText(this, "Reset password verification link sent to your email address.", Toast.LENGTH_LONG).show();
        }
    }
}
