package com.atmecs.devpractice;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomListAdapter extends BaseAdapter {
    private ArrayList<ListProvider> listData;
    private LayoutInflater layoutInflater;

    public CustomListAdapter(Context aContext, ArrayList<ListProvider> listData) {
        this.listData = listData;
        layoutInflater = LayoutInflater.from(aContext);
    }
    @Override
    public int getCount() {

        return listData.size();
    }
    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }
    @Override
    public long getItemId(int position) {
        return position;
    }
    public View getView(int position, View view, ViewGroup vg) {
        ViewHolder holder;
        if (view == null) {
            view = layoutInflater.inflate(R.layout.fragment_home, null);
            holder = new ViewHolder();
            holder.uName = (TextView) view.findViewById(R.id.name);
            holder.uLocation = (TextView) view.findViewById(R.id.location);
            view.setTag(holder);
        } else {
            holder = (ViewHolder) view.getTag();
        }
        holder.uName.setText(listData.get(position).getName());
        holder.uLocation.setText(listData.get(position).getLocation());
        return view;
    }
    static class ViewHolder {
        TextView uName;
        TextView uLocation;
    }
}
