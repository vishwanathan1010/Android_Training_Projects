package com.atmecs.devpractice.api;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import cz.msebera.android.httpclient.Header;

public class HTTPClientHandler {

   static APIResponseInterface apiResponseInterface;
    public static String responseBodyString;

    public HTTPClientHandler(APIResponseInterface responseInterface){
        this.apiResponseInterface =responseInterface;
    }


    public static void makePostAPICall(String url, RequestParams requestParameters) {
        AsyncHttpClient client = new AsyncHttpClient();

        client.addHeader("Content-Type", "application/x-www-form-urlencoded");

        client.post(url, requestParameters, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String responseBodyString = new String(responseBody);

                System.out.println("Success responseBodyString:" + responseBodyString);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                String responseBodyString = new String(responseBody);

                System.out.println("Failure responseBodyString:" + responseBodyString);
            }
        });
    }

        public static String makeGetAPICall(String url) {

            AsyncHttpClient client = new AsyncHttpClient();
            client.addHeader("Content-Type", "application/x-www-form-urlencoded");

            client.get(url, new AsyncHttpResponseHandler() {
                @Override
                public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                    responseBodyString = new String(responseBody);
                    apiResponseInterface.onResponseInterface(responseBodyString);
                    System.out.println("Success responseBodyString:" + responseBodyString);
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                    responseBodyString = new String(responseBody);

                    System.out.println("Failure responseBodyString:" + responseBodyString);
                }
            });
            return responseBodyString;
        }

    public static void makePutAPICall(String url, RequestParams requestParameters) {

        AsyncHttpClient client = new AsyncHttpClient();
        client.addHeader("Content-Type", "application/x-www-form-urlencoded");

        client.put(url, requestParameters, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String responseBodyString = new String(responseBody);

                System.out.println("Success responseBodyString:" + responseBodyString);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                String responseBodyString = new String(responseBody);

                System.out.println("Failure responseBodyString:" + responseBodyString);
            }
        });
    }
}
