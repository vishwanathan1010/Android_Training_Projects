package com.atmecs.devpractice;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.atmecs.devpractice.api.APIResponseInterface;
import com.atmecs.devpractice.api.ConstantsAPI;
import com.atmecs.devpractice.api.DevPracticeAPIManager;
import com.atmecs.devpractice.api.DevPracticeAPIServices;
import com.atmecs.devpractice.api.HTTPClientHandler;

import java.util.ArrayList;

public class UserDataFragment extends Fragment implements APIResponseInterface {
    public View rootView;
    public ListView listView;
    public ListAdapter adapter;
    public HTTPClientHandler clientHandler;
    public ArrayList list;

    public UserDataFragment(){
        clientHandler=new HTTPClientHandler(this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        rootView = inflater.inflate(R.layout.fragment_lists, container, false);
        DevPracticeAPIManager.getUserDataAPICall(ConstantsAPI.LIST_USERS_URL);
        listView = (ListView) rootView.findViewById(R.id.user_list);
        return rootView;

    }
    @Override
    public void onResponseInterface(String responseData) {

        list = DevPracticeAPIServices.onGetUserData(responseData);
        System.out.println("User data is :"+responseData);


        listView.setAdapter(new UserListAdapter(getActivity(),list));

    }
}
