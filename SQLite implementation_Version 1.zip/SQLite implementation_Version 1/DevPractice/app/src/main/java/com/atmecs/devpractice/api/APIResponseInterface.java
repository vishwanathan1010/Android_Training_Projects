package com.atmecs.devpractice.api;

public interface APIResponseInterface {

    void onResponseInterface(String responseData);
}
