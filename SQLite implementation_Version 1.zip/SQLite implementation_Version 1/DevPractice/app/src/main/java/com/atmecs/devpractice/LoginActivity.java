package com.atmecs.devpractice;

import androidx.appcompat.app.AppCompatActivity;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;

import android.os.Bundle;
import android.widget.Toast;

import com.atmecs.devpractice.api.DevPracticeAPIManager;
import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.ValidationStyle;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.RequestParams;

public class LoginActivity extends AppCompatActivity {
    private EditText editLoginEmail, editLoginPwd;
    private AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        TextView register = (TextView) findViewById(R.id.lnk_register);
        register.setMovementMethod(LinkMovementMethod.getInstance());
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        TextView forgotPassword = (TextView) findViewById(R.id.lnk_forgotpassword);
        forgotPassword.setMovementMethod(LinkMovementMethod.getInstance());
        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
                startActivity(intent);
            }
        });

        awesomeValidation = new AwesomeValidation(ValidationStyle.BASIC);

        editLoginEmail = (EditText) findViewById(R.id.input_login_email);
        editLoginPwd = (EditText) findViewById(R.id.input_login_email);

//        awesomeValidation.addValidation(this, R.id.input_login_email, Patterns.EMAIL_ADDRESS, R.string.login_email_error);
//        awesomeValidation.addValidation(this, R.id.input_login_pwd, "^((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})", R.string.pwd_error);

    }

    public void onLoginButtonClick(View view) {
        if (awesomeValidation.validate()) {

            String emailString =  editLoginEmail.getText().toString();
            String passwordString = editLoginPwd.getText().toString();



            AsyncHttpClient client = new AsyncHttpClient();

            RequestParams postParameters = new RequestParams();

            postParameters.put("email",emailString);
            postParameters.put("password",passwordString);

          //  DevPracticeAPIManager.getUserAPICall(postParameters);


            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Login Success", Toast.LENGTH_LONG).show();
        }
    }
}