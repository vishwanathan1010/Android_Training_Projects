package com.atmecs.devpractice.api;

import android.util.Log;

import com.atmecs.devpractice.UserList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
public class DevPracticeAPIServices {

    public static ArrayList contactList;

    public static ArrayList onGetUserData(String user_Data) {


        if (user_Data != null)
            try {
                contactList = new ArrayList<>();

                JSONObject jsonObj = new JSONObject(user_Data);
                JSONArray userList = jsonObj.getJSONArray("data");

                for (int index = 0; index < userList.length(); index++) {
                    JSONObject object = userList.getJSONObject(index);

                    UserList user_details=new UserList();

                    user_details.setId("ID: "+object.getString("id"));
                    user_details.setEmail("Email ID: "+object.getString("email"));
                    user_details.setFirstName("First Name: "+object.getString("first_name"));
                    user_details.setLastName("Last Name: "+object.getString("last_name"));
                    user_details.setImgUrl(object.getString("avatar"));


                    contactList.add(user_details);
                }

            }
            catch (JSONException errorMessage) {
                Log.e("JsonParser Example", "unexpected JSON exception", errorMessage);
            }
        else {
            System.out.println("Couldn't get json from server.");
        }
        return contactList;
    }

}