package com.atmecs.devpractice;


import androidx.fragment.app.Fragment;
import androidx.annotation.Nullable;

import android.content.Intent;
import android.view.View;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.atmecs.devpractice.com.atmecs.devpractice.database.SQLiteDatabaseHandler;

public class ProfileFragment extends Fragment implements View.OnClickListener{
    public EditText editFullName, editDesignation,editEmailID,editPhoneNumber,editSkills;
    public SearchView editSearch;
    public String fullNameString,designationString,emailString,phoneNumberString,skillsString,searchString;
    public static UserProfileInfo userDetails;
    Button submitButton,viewButton,updateButton;
    View rootView;
    TextView textView;
   // @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater,  ViewGroup container,  Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_profile_data, container, false);
        editFullName = (EditText) rootView.findViewById(R.id.data_fullName);
        editDesignation = (EditText) rootView.findViewById(R.id.data_designation);
        editEmailID = (EditText) rootView.findViewById(R.id.data_email);
        editPhoneNumber = (EditText) rootView.findViewById(R.id.data_phone_number);
        editSkills = (EditText) rootView.findViewById(R.id.data_skills);
        editSearch = (SearchView) rootView.findViewById(R.id.data_search_view);

        submitButton = rootView.findViewById(R.id.btn_submit);
        viewButton = (Button) rootView.findViewById(R.id.btn_view);
        updateButton = (Button) rootView.findViewById(R.id.btn_update);

        submitButton.setOnClickListener(this);
        viewButton.setOnClickListener(this);
        updateButton.setOnClickListener(this);

        return rootView;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_submit :
                System.out.println("Submit button clicked...");
                onSubmitButtonClick();
                break;
            case R.id.btn_view:
               onViewButtonClick();
                break;
            case R.id.btn_update:
               onUpdateButtonClick();
                break;
            default:
                System.out.println("Default Executed");
                break;
        }
    }

    public void onSubmitButtonClick(){
        SQLiteDatabaseHandler databaseHandler = new SQLiteDatabaseHandler(getActivity(), null, null, 1);

        fullNameString = editFullName.getText().toString();
        designationString = editDesignation.getText().toString();
        emailString = editEmailID.getText().toString();
        phoneNumberString = editPhoneNumber.getText().toString();
        skillsString = editSkills.getText().toString();
        //searchString = editSearch.getQuery().toString();

        UserProfileInfo userProfileInfo = new UserProfileInfo(fullNameString, designationString, emailString , phoneNumberString, skillsString);
        databaseHandler.addHandler(userProfileInfo);
        System.out.println("User Data is: "+userProfileInfo);
        editFullName.setText("");
        editDesignation.setText("");
        editEmailID.setText("");
        editPhoneNumber.setText("");
        editSkills.setText("");
        Toast.makeText(getActivity(), "User data submitted", Toast.LENGTH_LONG).show();

    }

    public void onViewButtonClick(){
        searchString = editSearch.getQuery().toString();
        SQLiteDatabaseHandler sqLiteDatabaseHandler = new SQLiteDatabaseHandler(getActivity(), null, null, 1);
        userDetails = sqLiteDatabaseHandler.viewHandler(SQLiteDatabaseHandler.TABLE_NAME,searchString);

        editFullName.setText(userDetails.getFullName());
        editDesignation.setText(userDetails.getDesignation());
        editEmailID.setText(userDetails.getEmailID());
        editPhoneNumber.setText(userDetails.getPhoneNumber());
        editSkills.setText(userDetails.getSkills());

        System.out.println("User data Fetched...");
        Toast.makeText(getActivity(), "User's data fetched", Toast.LENGTH_LONG).show();

    }

    public void onUpdateButtonClick(){
        Toast.makeText(getActivity(), "User's data updated", Toast.LENGTH_LONG).show();
        System.out.println("Update button clicked...");
    }
}
