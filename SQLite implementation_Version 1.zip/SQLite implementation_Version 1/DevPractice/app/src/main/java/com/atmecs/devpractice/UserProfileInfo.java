package com.atmecs.devpractice;

public class UserProfileInfo {

    public String fullName;
    public String designation;
    public String emailID;
    public String phoneNumber;
    public String skills;

    public UserProfileInfo() {}
    public UserProfileInfo(String fullName,String designation,String emailID,String phoneNumber,String skills) {
        this.fullName = fullName;
        this.designation = designation;
        this.emailID = emailID;
        this.phoneNumber = phoneNumber;
        this.skills=skills;
    }


    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
    public String getFullName() {
        return this.fullName;
    }


    public void setDesignation(String designation) {
        this.designation = designation;
    }
    public String getDesignation() {
        return this.designation;
    }



    public void setEmailID(String emailID) {
        this.emailID = emailID;
    }
    public String getEmailID() {
        return this.emailID;
    }


    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public String getPhoneNumber() {
        return this.phoneNumber;
    }



    public void setSkills(String skills) {
        this.skills = skills;
    }
    public String getSkills() {
        return this.skills;
    }

}
