package com.atmecs.devpractice.com.atmecs.devpractice.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;

import com.atmecs.devpractice.UserProfileInfo;

public class SQLiteDatabaseHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "userProfileDB.db";

    // Users table & column names
    public static final String TABLE_NAME = "Users";
    public static final String USER_ID = "ID";
    public static final String FULL_NAME = "FullName";
    public static final String DESIGNATION = "Designation";
    public static final String EMAIL_ID = "EmailID";
    public static final String PHONE_NUMBER = "PhoneNumber";
    public static final String SKILLS = "Skills";

    // Initialize the database
    public SQLiteDatabaseHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTableQuery =
                "CREATE TABLE " + TABLE_NAME + " (\n" +
                        USER_ID + " INTEGER PRIMARY KEY,\n" +
                        FULL_NAME + " TEXT NOT NULL,\n" +
                        DESIGNATION + " TEXT NOT NULL,\n" +
                        EMAIL_ID + " TEXT NOT NULL,\n" +
                        PHONE_NUMBER + " TEXT NOT NULL UNIQUE,\n" +
                        SKILLS + " TEXT NOT NULL\n" +
                        ");";

        sqLiteDatabase.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }


    public UserProfileInfo viewHandler(String tableName, String phoneNumber) {
        UserProfileInfo userProfileInfo = new UserProfileInfo();
        String result = "";
        String query = "select * from " + TABLE_NAME +" "+ "where"+" "+PHONE_NUMBER + " = "+"'"+phoneNumber+"'";
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        while (cursor.moveToNext()) {
            userProfileInfo.setFullName(cursor.getString(1));
            userProfileInfo.setDesignation(cursor.getString(2));
            userProfileInfo.setEmailID(cursor.getString(3));
            userProfileInfo.setPhoneNumber(cursor.getString(4));
            userProfileInfo.setSkills(cursor.getString(5));

        }
        cursor.close();
        sqLiteDatabase.close();
        System.out.println("Data Fetched from Database...");
        return userProfileInfo;
    }

    public void addHandler(UserProfileInfo userProfileInfoInfo) {
        ContentValues values = new ContentValues();
        values.put(FULL_NAME, userProfileInfoInfo.getFullName());
        values.put(DESIGNATION, userProfileInfoInfo.getDesignation());
        values.put(EMAIL_ID, userProfileInfoInfo.getEmailID());
        values.put(PHONE_NUMBER, userProfileInfoInfo.getPhoneNumber());
        values.put(SKILLS, userProfileInfoInfo.getSkills());
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.insert(TABLE_NAME, null, values);
        System.out.println("Data inserted successfully...");
        sqLiteDatabase.close();
    }


//    public UserProfileInfo findHandler(String userName) {
//        String query = "Select * FROM " + TABLE_NAME + "WHERE" + FULL_NAME + " = " + "'" + userName + "'";
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor = db.rawQuery(query, null);
//        UserProfileInfo userData = new UserProfileInfo();
//        if (cursor.moveToFirst()) {
//            cursor.moveToFirst();
//            userData.setFullName(cursor.getString(0));
//            userData.setDesignation(cursor.getString(1));
//            userData.setEmailID(cursor.getString(2));
//            userData.setPhoneNumber(cursor.getString(3));
//            userData.setSkills(cursor.getString(4));
//            cursor.close();
//        } else {
//            userData = null;
//        }
//        db.close();
//        return userData;
//    }

//    public boolean updateHandler(String fullName,String designation, String emailId, String phoneNumber, String skills ) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues args = new ContentValues();
//        args.put(FULL_NAME, fullName);
//        args.put(DESIGNATION, designation);
//        args.put(EMAIL_ID, emailId);
//        args.put(PHONE_NUMBER, phoneNumber);
//        args.put(SKILLS, skills);
//
//        return db.update(TABLE_NAME, args, PHONE_NUMBER + "=" + phoneNumber , null) > 0;
//    }

}
