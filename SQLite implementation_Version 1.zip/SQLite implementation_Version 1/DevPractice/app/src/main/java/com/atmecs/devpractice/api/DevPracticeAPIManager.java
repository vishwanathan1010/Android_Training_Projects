package com.atmecs.devpractice.api;

import com.loopj.android.http.RequestParams;

public class DevPracticeAPIManager {
 public static String getUserData;
    public static void getUserAPICall(RequestParams requestParameters){

        HTTPClientHandler.makePostAPICall(ConstantsAPI.LOGIN_URL,requestParameters);
    }

    public static void getUserDataAPICall(String url){

        HTTPClientHandler.makeGetAPICall(url);
    }

    public static void userUpdateAPICall(String url,RequestParams requestParameters){

        HTTPClientHandler.makePutAPICall(ConstantsAPI.PUT_URL,requestParameters);
    }

}